<?php get_header() ?>
    <?php if (have_posts()) { ?>
        <?php while(have_posts()){ ?>
            <?php the_post(); ?>
            <h2>
                <a href="<?php the_permalink('') ?>" title="<?php the_title_attribute() ?>"><?php the_title() ?></a>
            </h2>
            <div>
                <?php mytheme_post_meta(); ?>
                
                <div>
                    <?php the_excerpt(); ?>
                </div>
            </div>
            <?php mytheme_readMore_link(); ?>
        <?php } ?>
        <?php the_posts_pagination() ?>
   <?php } else { ?>
    <p><?php _e('Sorry, no posts match your criteria!', 'mytheme'); ?></p>
   <?php } ?>
<?php get_footer() ?>    
